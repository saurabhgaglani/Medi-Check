package com.example.medi_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

public class gp_details extends AppCompatActivity implements View.OnClickListener {

    private Button returnHome, submit;
    private EditText gpname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gp_details);

        returnHome = (Button) findViewById(R.id.returnHome);
        returnHome.setOnClickListener(this);

        submit = (Button) findViewById(R.id.button3);
        submit.setOnClickListener(this);

        gpname = (EditText) findViewById(R.id.editTextTextPersonName);

    }

    public void onClick(View v) {
        if (v == returnHome) {
            finish();
            startActivity(new Intent(this, HomePageActivity.class));
        }

        if (v == submit) {
            // Write a message to the database
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("message");
            String GPname = gpname.getText().toString().trim();

            myRef.setValue(GPname);
        }
    }
}